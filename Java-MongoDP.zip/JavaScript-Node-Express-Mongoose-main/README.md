A medium store api based back-end server with JavaScript | Node.js | Express | Mongoose
which returns products from mongoose database in json format
A Product Schema for mongoose
ErrorHandler middleware | NotFound middleware
Controller functions
A complex getAllProducts methods/Api which returns the products based on query parameters

How to use?
signup at cloud.mongodb.com create a database and copy the connection link.
create a dotenv file and add a variable name with such formate => DBCONNECT=paste_the_link_of_mongo_connection_uri_here
save the file and run the server on localhost setup app.js with your required properties or just run it with node app.js

need dummy data?
dont worry just run node populate.js and it will create 23 data entries into mongoose.
need random data of people firstname and last name with some description use generator.js
setup the api, mongoose, schema and run it standalone


